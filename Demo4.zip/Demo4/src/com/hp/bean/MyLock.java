package com.hp.bean;

public class MyLock {
	public  static final Object  lockA = new Object();
	public  static final Object  lockB = new Object();
	

}
