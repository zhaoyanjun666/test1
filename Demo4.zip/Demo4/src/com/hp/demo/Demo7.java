package com.hp.demo;

import com.hp.bean.Ticket;
import com.hp.bean.Ticket1;

public class Demo7 {
	public static void main(String[] args) {
		Ticket1 t = new Ticket1();
		Ticket t1 = new Ticket();
		Thread thread1 = new Thread(t, "����1");
		Thread thread2 = new Thread(t, "����2");
		Thread thread3 = new Thread(t, "����3");
		
		thread1.start();
		thread2.start();
		thread3.start();
	}
}
