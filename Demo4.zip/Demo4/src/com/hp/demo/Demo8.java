package com.hp.demo;

import com.hp.bean.RWLock;

public class Demo8 {
	public static void main(String[] args) {
		RWLock r = new RWLock();
		for (int i = 0; i < 100; i++) {
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					r.get();
					
				}
			},"��").start();
		}
		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				r.set((int)(Math.random()*101));
				
			}
		},"д").start();
		
		
	}
}
