package com.hp.demo;

import com.hp.bean.TestLock;

public class Demo6 {
	public static void main(String[] args) {
		TestLock lock = new TestLock();
		Thread t1 = new Thread(lock);
		Thread t2 = new Thread(lock);
		t1.start();
		t2.start();
		
	}
}
