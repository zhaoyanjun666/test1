package com.hp.demo;

public class Demo1 {
	public static void main(String[] args) {
		
		function();
		System.out.println("End!");
		
		
		
	}
	public static void function(){
		for (int i = 0; i < 100000; i++) {
			System.out.println(i);
		}
		
	}
	
	
}
