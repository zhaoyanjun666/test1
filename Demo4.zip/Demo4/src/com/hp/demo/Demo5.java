package com.hp.demo;

import com.hp.bean.Ticket;

public class Demo5 {
	public static void main(String[] args) {
		Ticket t = new Ticket();
		Ticket t1 = new Ticket();
		Thread thread1 = new Thread(t, "����1");
		Thread thread2 = new Thread(t, "����2");
		Thread thread3 = new Thread(t, "����3");
		
		thread1.start();
		thread2.start();
		thread3.start();
		
	}
}
